# datacollection

A flutter application to access gyroscope and accelerometer data from Android devices and store it in a .txt file for further analysis.

## Getting Started

->This code can be exported as apk and used on Android devices.
->The data will be exported with time stamp and name to the root android folder( Edit the code to change the path as needed)
