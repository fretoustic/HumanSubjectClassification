package com.example.datacollection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
